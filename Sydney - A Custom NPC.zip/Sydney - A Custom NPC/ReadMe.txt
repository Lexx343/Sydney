Hello, and thank you for choosing to download my mod! It was a long labor of love
For those unfamiliar with SDV modding, getting my mod to work is as simple as 5 easy steps
-Download and install the latest version of SMAPI following its instructions
-Download and install the latest version of Content Patcher following its instructions
-Download and install the latest version of Mail Framework Mod following its instructions
-Drag this mod into the "mods" folder of your SDV main directory, if you for some reason don't have one, just create a new folder there and label it as "Mods"
-Launch SDV with SMAPI 

Additonally, SMAPI will tell you when I've updated this mod! Or alert you to any nasty errors. Be sure to thank PathosChild for all of his hard work.

(Free Love Compatibility)
Both mods are *technically* compatible, however if you have children with my character while also married to other characters you can expect to see some weird text during that process. It's not game breaking, just vaguely immersion breaking. A fix for this issue is likely to arrive post SDV 1.6

If you have any questions or issues with my mod feel free to ping me at the SDV discord @Lex in "modded-game-support" I don't bite!

With all of that being said, I hope you enjoy the mod!